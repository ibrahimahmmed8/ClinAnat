# ClinAnat — Human Anatomy Android app

This is an offline Android wrapper for the provided **ClinAnat — Human Anatomy App.html**. The anatomy content and interactive screens are packaged in `app/src/main/assets/index.html`. There is no Internet permission and no external fonts are fetched.

## Build an APK with Android Studio

1. Install Android Studio and its Android SDK Platform 35.
2. Open the `ClinAnat-Android` folder as a project.
3. Wait for Gradle sync and choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Find the installable debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer the APK to your Android device and approve installation from the relevant source.

## Build automatically on GitHub (no local Android Studio required)

1. Create a new GitHub repository and upload the contents of this project, including `.github/workflows/build-apk.yml` (not just the zip).
2. Open the repository's **Actions** tab and select **Build ClinAnat APK**.
3. Click **Run workflow**, or push the project to `main`/`master`.
4. Open the completed workflow run and download the **ClinAnat-debug-APK** artifact. Unzip it to get `app-debug.apk`.

## Notes

- App ID: `org.clinanat.app` — version 1.0.0.
- Android 6.0 and later (API 23+).
- All supplied HTML anatomy material is retained. The Markdown provides an abbreviated outline and is not substituted for the more detailed HTML.
- No 3D anatomical models or new medical illustrations were in the provided files.
- This is an educational prototype. Its clinical facts have **not** been independently reviewed or validated for patient-care decisions.
- The generated debug APK is automatically debug-signed and suitable for personal testing, not for publishing to Google Play. Release distribution requires a private release signing key and review of current Play requirements.
