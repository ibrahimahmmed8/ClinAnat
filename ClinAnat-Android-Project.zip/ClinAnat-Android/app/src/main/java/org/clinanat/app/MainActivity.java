package org.clinanat.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.window.OnBackInvokedDispatcher;
import android.os.Build;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xff0d1117);
        getWindow().setNavigationBarColor(0xff0d1117);
        webView = new WebView(this);
        webView.setBackgroundColor(0xff0d1117);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); // Existing ClinAnat navigation and search use JavaScript.
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(true); // Required for bundled android_asset HTML.
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"file".equals(request.getUrl().getScheme());
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::goBackInApp);
        }
    }

    private void goBackInApp() {
        webView.evaluateJavascript("window.clinanatBack && window.clinanatBack()", result -> {
            if (!"true".equals(result)) runOnUiThread(this::finish);
        });
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT < 33) goBackInApp();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
